#include <stdio.h>

typedef struct {
        char name[50];
        unsigned long fnom;
        float avmark;
} student;
typedef struct node {
        char name[50];
        unsigned long fnom;
        float avmark;
        struct node* next;
} studentList;

typedef enum {false,true} bool;

bool readFromFile(char *fname, studentList** head);
float averageMark(studentList* head);
bool insertStudent(studentList** head, student data);
bool writeIntoFile(char *fname, studentList* head);
void deleteList(studentList**head);
